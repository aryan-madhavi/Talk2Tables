
  # Frontend UI Design for Talk2Tables

  This is a code bundle for Frontend UI Design for Talk2Tables. The original project is available at https://www.figma.com/design/pllmNcRcfQG2bu3VVzDMPD/Frontend-UI-Design-for-Talk2Tables.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  